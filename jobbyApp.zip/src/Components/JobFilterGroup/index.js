import ProfileDetails from '../ProfileDetails';
import './index.css'

const JobFilterGroup = (props)=>{
    const {employementTypesList,salaryRangeList,changeEmployemetType,changeSalary,searchInput,getJobs}=props;

    
    return(
        <div className='job-filter-group'>
            <ProfileDetails />
            <hr className='horizontal-line'/>
            <h1>EmployementList</h1>
            <hr className='horizontal-line'/>
            <h1>salary Range</h1>
        </div>
    )
}
export default JobFilterGroup;