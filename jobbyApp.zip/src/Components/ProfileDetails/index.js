import { useEffect, useState } from "react";
import Cookies from "js-cookie";

const apiStatusConstants = {
    initial: "INITIAL",
    inProgress: "INPROGRESS",
    success: "SUCCESS",
    failure: "FAILURE"
}
const ProfileDetails=() =>{
    const [profileList,setProfileList]=useState({});
    const [apiStatus,setApiStatus]=useState(apiStatusConstants.initial)

    useEffect(()=>{
        getProfileDetails();
    } ,[]);

    const getProfileDetails = async ()=>{
        setApiStatus(apiStatusConstants.inProgress)
        const jwtToken = Cookies.get('jwt-token')
        
        const url = `http://localhost:4446/auth/profile`
        const options = {
            headers: {
                Authorization: `Bearer ${jwtToken}`
            },
            method: "GET"
        };

        try {
            const response = await fetch(url, options)
            // console.log(response);
            if (response.ok === true) {
                const data = await response.json();
                setProfileList(data)
                setApiStatus(apiStatusConstants.success)
            }
            else {
                setApiStatus(apiStatusConstants.failure)
            }
        }
        catch (e) {
            console.log(e);
            setApiStatus(apiStatusConstants.failure)
        }
    }
    
    return (
        <></>
    )
}
export default ProfileDetails;